import nltk
from google.cloud import translate
import os
import random
from bs4 import BeautifulSoup
import requests
from xml.sax import saxutils as su

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "auth.json"

new_thing = requests.get("https://poestories.com/read/amontillado")
text_thing = new_thing.text
soup = BeautifulSoup(text_thing, 'html.parser')

AllP = []

for link in soup.find_all('p'):
    AllP.append(link.get_text())


def translate_text(target, text):
    translate_client = translate.Client()
    #text = text.decode('utf-8')
    result = translate_client.translate(text, target_language=target)
    return su.unescape(result['translatedText'])

def random_chance(diff):
    x = (80*diff/9) + (100/9);

    if random.randint(0,99) <=  x :
        return True
    else:
        return False

css = ""
j=0;
resultt = []


for paragraph in AllP:
    initParagraph = paragraph

    # N, V, or A
    type = [False, True, True];

    language = "fr"

    # Difficulty 1-10 20% - 100%
    difficulty = 10;


    # Parses words into vector
    words = nltk.word_tokenize(paragraph);

    # IDs words, places in tuples with first element as word and second as Part of Speech
    partOfSpeech = nltk.pos_tag(words)

    toTranslate = []
    translated = []

    # Iterates through part of speech and saves locations of nouns
    for idx, i in enumerate(partOfSpeech):
        if random_chance(difficulty):
            if i[1][:2] == "NN" and type[0] == True :
                toTranslate.append(i[0])
                translated.append(translate_text(language, i[0]))
            if i[1][:1] == "V" and type[1] == True:
                toTranslate.append(i[0])
                translated.append(translate_text(language, i[0]))
            if i[1][:2] == "JJ" and type[2] == True:
                toTranslate.append(i[0])
                translated.append(translate_text(language, i[0]))

    for i in range( len(toTranslate)-1 ):
        location = paragraph.find( toTranslate[i], 0, len(paragraph) )
        paragraph = paragraph[0:location] + "<code id='f"+ str(j) +"'></code>" + paragraph[location + len(toTranslate[i]):]
        css += "#f" + str(j) + ":after{content: '" + translated[i] + "' !important;}\n#f" + str(j) + ":hover:after{content: '" + toTranslate[i] + "'!important ;}\n\n"
        j = j+1;

    resultt.append(paragraph)

    #print paragraph
    #print css

j = 0
for i in soup.find_all('p'):
    i.string = resultt[j]
    j = j+1

f = open('product.html','w')


f.write(su.unescape( str(soup)))
f.close()

f = open('style.css','w')
f.write(css.encode('utf-8'))
f.close()
