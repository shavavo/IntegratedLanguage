paragraphs = document.querySelectorAll("p");

for (i = 0; i < paragraphs.length; i++){
  paragraphs[i].innerHTML = "NF"
}

console.log(paragraphs);
