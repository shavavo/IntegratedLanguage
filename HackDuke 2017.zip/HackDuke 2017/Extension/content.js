const e = document.getElementById("languageSelect");
const NOUNS = document.getElementById("nouns");
const VERBS = document.getElementById("verbs");
const ADJS = document.getElementById("adjectives");
const DIFF =  document.getElementById("difficulty");
const START = document.getElementById("start");



var language;
var NVA = "";
var nouns = false;
var verbs = false;
var adjs = false;
var difficulty = 10;

function selectLanguage(){
  var language = e.options[e.selectedIndex].value;
  //console.log(language);
}

function selectDiff(){
  var difficulty = DIFF.options[DIFF.selectedIndex].value;
  //console.log(difficulty);
}

function checkNouns() {
  nouns = NOUNS.checked
  VERBS.checked = false;
  ADJS.checked = false;
  //console.log( NOUNS.checked );
}

function checkVerbs() {
  verbs = VERBS.checked
  NOUNS.checked = false;
  ADJS.checked = false;
  //console.log( VERBS.checked );
}

function checkAdjs() {
  adjs = ADJS.checked
  NOUNS.checked = false;
  VERBS.checked = false;
  //console.log( ADJS.checked )
}

function translate(){
  // Initialize
  NVA = [nouns, verbs, adjs]
  //console.log(NVA);
  chrome.tabs.executeScript({
    file: 'inject.js'
  });

  //window.close();

}



ADJS.addEventListener('click', checkAdjs, false)
VERBS.addEventListener('click', checkVerbs, false)
NOUNS.addEventListener('click', checkNouns, false)
DIFF.addEventListener('click', selectDiff, false)
DIFF.addEventListener('change', selectDiff, false)
e.addEventListener('click', selectLanguage, false)
e.addEventListener('change', selectLanguage, false)
START.addEventListener('click',translate,false)
