var config = {
  TRANSLATE_API_KEY: "AIzaSyDNgBm4Dx_VPVLPZix8JQHDkLO1RI3OC-U"
}

var clientID = "Vyrcd9rkrQ";
var secret = "67g6hDJYBhthpFTGpBNf4m";
